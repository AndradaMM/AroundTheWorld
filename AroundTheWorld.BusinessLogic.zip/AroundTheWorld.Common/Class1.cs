﻿using System;

namespace AroundTheWorld.Common
{
    public class Class1
    {
    }
}
