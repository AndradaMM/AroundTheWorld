﻿using AroundTheWorld.BusinessLogic.Entities;
using AroundTheWorld.BusinessLogic.IRepositories;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Text;

namespace AroundTheWorld.BusinessLogic.Services
{
    public class DiaryService
    {
        //private IDiaryRepository _diaryRepository;

        //public DiaryService(IDiaryRepository diaryRepository)
        //{
        //    _diaryRepository = diaryRepository;
        //}

        //public void Add(Diary diary)
        //{
        //    _diaryRepository.Add(diary);
        //}

        //public void Update(Diary diary)
        //{

        //}

        //public void Remove(Diary diary)
        //{
        //    _diaryRepository.Remove(diary);
        //}

        //public void 



    }
}
